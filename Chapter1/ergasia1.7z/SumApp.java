package gr.aueb.cf.ch1;

public class SumApp {
    public static void main(String[] args) {
        int num1 = 19;
        int num2 = 30;
        int summarize1plus2 =0;
        summarize1plus2=num1 + num2;
        System.out.printf(" Το αποτέλεσμα της πρόσθεσης είναι ίσο με :"+ summarize1plus2)
        ;
    }
}
