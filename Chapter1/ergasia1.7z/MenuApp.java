package gr.aueb.cf.ch1;

public class MenuApp {
    public static void main(String[] args) {
        System.out.println("1. Εισαγωγή"+"\n"+"2. Διαγραφή"+"\n"+"3. Αναζήτηση"+"\n"+"4. Ενημέρωση"+"\n"+"5. Έξοδος"+"\n"+"Δώστε Αριθμό Επιλογής:");
    }
}
